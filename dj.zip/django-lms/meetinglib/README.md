# Google_Calendar_API
Python booking application that make use of Google Calendar API to book and cancel appointment.
